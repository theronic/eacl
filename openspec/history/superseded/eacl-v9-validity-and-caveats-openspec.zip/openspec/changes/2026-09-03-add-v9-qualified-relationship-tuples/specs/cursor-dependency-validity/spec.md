## ADDED Requirements

### Requirement: Temporal continuations bind valid-at and stability horizon

Every cursor or continuation for an operation that can observe
validity-qualified relationships SHALL authenticate the selected `valid-at` and
the temporal stability horizon of its materialized page or traversal state.
Resumption SHALL either preserve that temporal view while its certificate
remains valid or perform documented recovery/restart against a new temporal
snapshot.

A continuation MUST NOT silently combine a page computed before a validity
boundary with traversal state evaluated after that boundary.

#### Scenario: Resume before temporal boundary

- **WHEN** a cursor resumes on a dependency-equivalent database before its
  exclusive temporal horizon
- **THEN** EACL may reuse the continuation under its original `valid-at`

#### Scenario: Resume at temporal boundary

- **WHEN** a cursor resumes at or after its exclusive temporal horizon
- **THEN** EACL rejects, restarts, or rebases according to the documented
  continuation policy
- **AND** does not silently reuse stale state

#### Scenario: Explicit administrative valid-at

- **WHEN** a cursor was issued for an explicit administrative valid-time
- **THEN** resumption preserves that exact time unless the caller starts a new
  query

#### Scenario: Unrelated database churn

- **WHEN** unrelated transactions occur while valid-time and relation dependency
  certificates remain valid
- **THEN** those transactions do not by themselves invalidate continuation

### Requirement: Caveat request context is authenticated continuation scope

A Caveat-aware cursor SHALL authenticate the complete canonical request context,
the Caveat compatibility profile/evaluator identity, and the conditional result
semantics needed to reproduce its page. Context supplied on resumption SHALL
match the authenticated scope or cause a typed mismatch or restart.

Relationship-bound context remains database dependency data: the cursor proof
SHALL cover each relevant context eid/payload and Caveat definition through the
selected snapshot proof.

#### Scenario: Request context changes between pages

- **WHEN** a caller resumes a cursor with different Caveat request context
- **THEN** EACL rejects the continuation or starts a separately scoped query
- **AND** does not reuse the prior traversal frontier

#### Scenario: Bound context changes between pages

- **WHEN** `:touch` replaces a relationship's Caveat context before resumption
- **THEN** relation and content proof validation prevent old continuation reuse

#### Scenario: Caveat definition changes

- **WHEN** schema replacement changes a referenced Caveat before resumption
- **THEN** schema validation rejects or recovers the continuation according to
  policy

#### Scenario: Evaluator identity changes

- **WHEN** the Caveat evaluator compatibility fingerprint changes
- **THEN** old Caveat-aware cursors are incompatible

### Requirement: Conditional lookup state is stable across pages

Caveat-aware lookup cursors SHALL preserve whether each returned membership is
definite or conditional and SHALL authenticate retained missing-context or
residual-condition data. A continuation MUST NOT turn a conditional candidate
into a definite grant or omit a definite candidate because condition state was
lost.

#### Scenario: Conditional candidate crosses page boundary

- **WHEN** a conditional lookup candidate is the last item on one page or first
  item on the next
- **THEN** its permissionship and missing-context fields remain reproducible

#### Scenario: Definite and conditional candidates share an object id

- **WHEN** multiple permission paths reach one object with different condition
  states
- **THEN** pagination applies the permission algebra before emitting one
  correctly classified result
- **AND** does not emit duplicate object identities

#### Scenario: Boolean compatibility lookup

- **WHEN** a compatibility lookup omits conditional results
- **THEN** its cursor scope records that result policy
- **AND** it cannot resume through a Caveat-aware result policy

### Requirement: v9 cursors commit to fixed eight-slot relationship ordering

Relationship-read and authorization cursors SHALL identify the v9 endpoint ABI
and the ordering boundary derived from endpoint component four. Trailing Caveat,
context, and validity qualifiers SHALL be authenticated where needed for exact
stored-relationship enumeration, while effective authorization pagination
remains ordered by the opposite endpoint identity.

#### Scenario: Old cursor reaches v9

- **WHEN** a cursor was minted for a four-slot or seven-slot experimental
  relationship ABI
- **THEN** the v9 client rejects it as incompatible

#### Scenario: Qualifiers change at the boundary relationship

- **WHEN** `:touch` changes qualifiers on a relationship used as a stored-read
  continuation boundary
- **THEN** dependency and cursor validation prevent the old physical boundary
  from being mistaken for its replacement

#### Scenario: Full-arity vector bound

- **WHEN** DataScript resumes a stored relationship scan
- **THEN** its comparator boundary uses the complete eight-element vector shape
- **AND** qualifier values cannot shift the endpoint ordering contract
