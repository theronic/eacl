## MODIFIED Requirements

### Requirement: Two-value endpoint representation

Each EACL relationship SHALL be represented by exactly two cardinality-many,
indexed, authoritative endpoint values: a forward value on the subject entity
and a reverse value on the resource entity. The values SHALL use this fixed
eight-component v9 order:

- forward:
  `[subject-type relation-eid resource-type resource-eid caveat-eid caveat-context-eid valid-from-ms valid-until-ms]`
- reverse:
  `[resource-type relation-eid subject-type subject-eid caveat-eid caveat-context-eid valid-from-ms valid-until-ms]`

The first four components SHALL identify the logical relationship. Components
five through eight SHALL be qualifiers and SHALL be `nil` when absent. Both
physical halves SHALL contain the same Caveat definition ref, Caveat context
ref, and validity bounds.

A non-nil Caveat context ref SHALL require a non-nil Caveat definition ref. A
non-nil Caveat definition ref with a nil context ref SHALL represent a Caveat
with empty relationship-bound context. EACL SHALL store no entity whose sole
purpose is to represent every relationship.

#### Scenario: Permanent uncaveated relationship

- **WHEN** EACL creates a relationship without a Caveat or validity bounds
- **THEN** it stores exactly one eight-slot forward value and one eight-slot
  reverse value
- **AND** slots five through eight are `nil`
- **AND** it stores no relationship entity

#### Scenario: Validity-only relationship

- **WHEN** EACL creates a relationship with validity bounds and no Caveat
- **THEN** slots five and six are `nil`
- **AND** slots seven and eight contain the normalized validity bounds
- **AND** both endpoint halves contain identical qualifiers

#### Scenario: Caveat with empty bound context

- **WHEN** Phase 2 creates a relationship with a Caveat and no
  relationship-bound context values
- **THEN** slot five contains the Caveat definition eid
- **AND** slot six is `nil`
- **AND** no Caveat context entity is allocated

#### Scenario: Caveat with bound context

- **WHEN** Phase 2 creates a relationship with non-empty relationship-bound
  Caveat context
- **THEN** slot five contains the Caveat definition eid
- **AND** slot six contains the same sparse Caveat context eid in both halves
- **AND** the context payload is not duplicated inside the endpoint values

#### Scenario: Context without Caveat

- **WHEN** an update supplies or stored data contains a non-nil slot six with a
  nil slot five
- **THEN** admitted writes reject it
- **AND** authorization treats an out-of-band value as non-granting corruption

#### Scenario: Duplicate complete physical value

- **WHEN** the same complete eight-slot endpoint value is added more than once
  in one database value
- **THEN** database set semantics retain one datom for that endpoint value

### Requirement: Ordered endpoint index access

Every backend adapter SHALL implement exact matching, adjacency, relationship
filtering, relation-in-use checks, and forward and reverse pagination using the
single v9 endpoint attribute appropriate to the requested direction. The first
three components SHALL remain the typed relation prefix, the fourth component
SHALL remain the opposite endpoint used for ordering and pagination, and all
four qualifier components SHALL remain trailing.

Every tuple/vector seek boundary SHALL use the complete stored arity required by
the backend ordering contract. Normal v9 authorization and relationship reads
MUST NOT scan, union, merge, or prefer values from a v7 relationship attribute.

#### Scenario: Forward endpoint scan

- **WHEN** authorization or relationship pagination scans outward from a known
  subject
- **THEN** the adapter performs one seek against that subject's v9 forward
  endpoint values
- **AND** returns candidates ordered by resource eid before evaluating
  qualifiers

#### Scenario: Reverse endpoint scan

- **WHEN** authorization or relationship pagination scans inward from a known
  resource
- **THEN** the adapter performs one seek against that resource's v9 reverse
  endpoint values
- **AND** returns candidates ordered by subject eid before evaluating
  qualifiers

#### Scenario: Exact logical relationship probe

- **WHEN** EACL probes one known subject, relation, and resource
- **THEN** it seeks by the first four components using full eight-slot low and
  high bounds
- **AND** obtains zero or one well-formed logical relationship
- **AND** treats multiple qualifier variants as corruption rather than choosing
  a grant

#### Scenario: Reverse-order continuation

- **WHEN** a descending scan resumes from a relationship cursor
- **THEN** `rseek-datoms` or its backend equivalent starts from a full
  eight-slot bound
- **AND** returns only values inside the requested endpoint prefix and ordering
  boundary

#### Scenario: Adjacent prefix is absent

- **WHEN** no value exists for a requested prefix but an adjacent prefix exists
- **THEN** explicit entity, attribute, arity, and component guards prevent the
  adjacent value from being returned

#### Scenario: Legacy attributes remain installed but empty

- **WHEN** a Datomic database still has immutable v7 attribute definitions but
  no v7 relationship datoms
- **THEN** v9 reads never seek those attributes
- **AND** their schema presence adds no per-hop second seek

### Requirement: One logical relationship regardless of qualifiers

Logical relationship identity SHALL consist only of the first four endpoint
components. Caveat definition, Caveat context, `valid-from`, and `valid-until`
SHALL NOT create distinct relationships. At most one stored relationship SHALL
exist for a logical identity.

This rule SHALL match SpiceDB behavior: relationships differing only in Caveat,
Caveat context, or expiration cannot coexist.

#### Scenario: Different Caveat is not a second relationship

- **WHEN** a relationship already exists and a caller attempts `:create` with
  the same logical identity and a different Caveat
- **THEN** EACL reports `:eacl/relationship-conflict`

#### Scenario: Different context is not a second relationship

- **WHEN** a relationship already exists and a caller attempts `:create` with
  different relationship-bound context
- **THEN** EACL reports `:eacl/relationship-conflict`

#### Scenario: Different validity is not a second relationship

- **WHEN** a relationship already exists and a caller attempts `:create` with
  different validity bounds
- **THEN** EACL reports `:eacl/relationship-conflict`

#### Scenario: Out-of-band variants coexist

- **WHEN** multiple complete endpoint values share the first four components
- **THEN** integrity reports a logical-identity collision
- **AND** authorization treats that logical edge as non-granting
- **AND** no qualifier precedence rule silently selects one variant

### Requirement: Atomic pair mutation and repair

Relationship mutation SHALL add, replace, or retract both v9 endpoint values in
one admitted transaction and SHALL preserve `:create`, `:touch`, and `:delete`
semantics over the first-four-component logical identity.

`:create` SHALL conflict with every stored temporal or Caveat state.
`:touch` SHALL create when absent and otherwise replace the exact old endpoint
pair, Caveat context entity, and expiration index with the requested canonical
state. `:delete` SHALL require only the logical relationship and SHALL remove
all discoverable physical variants so it can repair bounded corruption.

#### Scenario: Racing creates with different qualifiers

- **WHEN** two `:create` transactions for one logical identity are planned
  against the same pre-write value with different qualifiers
- **THEN** exactly one creation commits
- **AND** the other fails with `:eacl/relationship-conflict`
- **AND** one canonical forward/reverse pair remains

#### Scenario: Touch replaces all qualifiers

- **WHEN** `:touch` changes the Caveat, relationship-bound context, or validity
- **THEN** EACL retracts the exact old forward and reverse values
- **AND** adds one matching new pair
- **AND** creates/retracts sparse context and expiration data atomically
- **AND** advances the affected relation mutation identity exactly once

#### Scenario: Touch is unchanged

- **WHEN** `:touch` supplies qualifiers canonically equal to the stored state
- **THEN** EACL may treat the operation as an idempotent no-op
- **AND** it does not allocate an unnecessary replacement context entity

#### Scenario: Repeated and conflicting batch updates

- **WHEN** one batch repeats an identical update for one logical relationship
- **THEN** the batch has the same outcome as one occurrence
- **WHEN** one batch contains semantically different updates for that identity
- **THEN** EACL rejects it with
  `:eacl/invalid-relationship-update-batch` before transaction submission

#### Scenario: Incomplete relationship repair

- **WHEN** `:touch` targets missing, mismatched, or duplicated endpoint halves
- **THEN** EACL removes bounded discoverable variants and writes one matching
  canonical pair

#### Scenario: Delete omits qualifiers

- **WHEN** `:delete` supplies the subject, relation, and resource but no Caveat,
  context, or validity
- **THEN** EACL removes the matching logical relationship if present
- **AND** removes its singly-owned context and expiration-index data

### Requirement: Endpoint deletion and integrity

Every backend adapter SHALL treat peer eids, Caveat definition eids, and Caveat
context eids embedded in endpoint values according to its native value
semantics. EACL object cleanup SHALL explicitly remove every touching endpoint
pair and owned auxiliary data before endpoint retraction.

The module SHALL expose an offline integrity report covering malformed arity,
dangling or mismatched halves, qualifier disagreement, first-four identity
collisions, invalid Caveat/context combinations, missing or multiply-owned
context entities, malformed intervals, and stale or missing expiration-index
entries. Integrity faults MUST NOT become unconditional grants.

#### Scenario: EACL object cleanup

- **WHEN** `delete-object!` removes an endpoint
- **THEN** it removes local and peer endpoint values for every touching
  relationship
- **AND** removes singly-owned Caveat context and expiration-index values
- **AND** publishes every affected relation mutation identity

#### Scenario: Direct endpoint retraction

- **WHEN** a consumer retracts an endpoint entity outside EACL
- **THEN** peer halves and context entities can remain as detectable corruption
  because embedded refs are not relied upon for automatic cascading

#### Scenario: Integrity scan

- **WHEN** the offline integrity report scans the database
- **THEN** it reports each invalid pair, identity collision, Caveat/context
  fault, interval fault, or auxiliary-index mismatch without mutating data

#### Scenario: Corrupt relationship reaches authorization

- **WHEN** authorization encounters any integrity fault on a candidate
- **THEN** that logical edge is non-granting
- **AND** a typed diagnostic is available

### Requirement: Database-visible proof coverage

Unknown-writer relationship proofs SHALL commit to both complete eight-slot
endpoint values, the public identities of their endpoints, all authoritative
relationship-bound Caveat context payloads, and every answer-affecting derived
validity index value. A proof MUST change when any answer-affecting relationship
qualifier or referenced context changes out of band.

Caveat definitions SHALL be covered by the schema proof and generation.

#### Scenario: One half changes out of band

- **WHEN** one endpoint half changes for a relation in a cached request's
  dependency closure
- **THEN** the next content-proof validation rejects the previous answer

#### Scenario: Context payload changes out of band

- **WHEN** a referenced context entity retains its eid but its payload changes
- **THEN** the database-visible content proof changes
- **AND** the prior answer is not reused

#### Scenario: Qualifier ref changes out of band

- **WHEN** either Caveat ref, either validity bound, or an expiration-index
  value changes without an admitted relation-version update
- **THEN** the content proof changes and prior reuse is rejected

#### Scenario: Endpoint identity changes out of band

- **WHEN** an endpoint's public identity changes while its eid remains stable
- **THEN** the content proof changes and prior authorization results are not
  reused

### Requirement: Shared logical storage layer

The core workspace SHALL provide backend-neutral pure functions for fixed-arity
v9 endpoint construction, decoding, logical-identity extraction, Caveat/context
qualifier validation, peer-half construction, exact retractions, interval
validation, and prefix validation wherever all backends share behavior.
Backend-specific index, transaction, clock, schema, and history operations SHALL
remain inside adapters.

#### Scenario: Equivalent relationship

- **WHEN** all supported adapters encode the same relationship and qualifiers
- **THEN** their forward and reverse values have identical eight-component
  order
- **AND** decode to the same endpoints, Caveat ref, context ref, and validity

#### Scenario: Permanent normalization

- **WHEN** a relationship omits every qualifier
- **THEN** the shared codec emits four explicit trailing `nil` values rather
  than a shorter value

#### Scenario: Backend-specific database access

- **WHEN** an adapter reads or writes endpoint values
- **THEN** it uses its native APIs without introducing backend dependencies
  into the shared codec

### Requirement: Rebuild-only v9 compatibility boundary

The v9 adapter SHALL use only the eight-slot endpoint-pair layout for
authorization, mutation, reads, cleanup, integrity, and proof generation. EACL
SHALL NOT provide an automatic v7-to-v9 relationship migration, dual-read
compatibility mode, mixed-format authorization path, or per-relation fallback.

A v9 client SHALL refuse startup when v7 relationship datoms remain or when the
persisted relationship-storage version is incompatible. It SHALL provide typed
rebuild/reseed guidance. Legacy Datomic schema definitions MAY remain inert.

#### Scenario: Populated v7 database

- **WHEN** a v9 client opens a database containing any v7 forward or reverse
  relationship datom
- **THEN** startup fails with `:eacl/storage-version`
- **AND** no authorization request interprets the old data
- **AND** the error directs the operator to rebuild or reseed Relationships

#### Scenario: Fresh or rebuilt database

- **WHEN** a database contains no old relationship datoms and has the required
  v9 schema
- **THEN** EACL stamps or validates relationship storage version 9
- **AND** every subsequently admitted relationship uses only v9 values

#### Scenario: Mixed relationship data

- **WHEN** both v7 and v9 relationship datoms are detected
- **THEN** EACL fails closed at startup rather than merging the graphs

#### Scenario: Old cache or cursor

- **WHEN** a cache artifact or cursor was produced for the old relationship ABI
- **THEN** v9 rejects it through the cache, engine, adapter, or token ABI
  boundary

### Requirement: Cross-runtime validation

The v9 endpoint-pair adapter SHALL satisfy the shared backend contract and each
backend's storage, pagination, consistency, mutation, cache-proof, cleanup,
integrity, temporal, and Caveat tests. DataScript SHALL satisfy the same logical
contract on JVM and ClojureScript runtimes.

#### Scenario: JVM backend suites

- **WHEN** Datomic Pro, Datahike, Datalevin, and DataScript JVM suites run
- **THEN** direct and recursive authorization, lookup, count, relationship
  reads/writes, qualifier evaluation, cache proof, cleanup, collection, and
  integrity behavior pass

#### Scenario: ClojureScript suite

- **WHEN** the compiled DataScript ClojureScript suite runs under Node
- **THEN** fixed eight-slot ordering, seeks, pagination, validity, Caveat
  evaluation, mutation, and corruption handling match JVM semantics

#### Scenario: Single-source traversal benchmark

- **WHEN** v9 direct checks, adjacency, arrows, lookup, and pagination are
  benchmarked against v7
- **THEN** every logical relation hop performs one authoritative endpoint seek
- **AND** tuple-width and active-Caveat overhead are measured without a hidden
  v7 fallback
