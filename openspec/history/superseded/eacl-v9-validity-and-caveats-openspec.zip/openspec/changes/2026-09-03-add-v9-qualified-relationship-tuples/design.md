## Context

See `proposal.md` for motivation. EACL v8 retains the v7 persisted relationship
ABI: one four-component forward tuple on the subject and one four-component
reverse tuple on the resource. The shared codec, backend adapters, ordered
scans, mutation guards, cleanup, integrity, cache proofs, and cursors all assume
that shape.

The v7 representation is efficient because one endpoint-local seek returns the
opposite eid directly. The former relationship-entity representation used seven
datoms per relationship and still required covering indexes for efficient
forward and reverse traversal. v9 must preserve the two-datom hot path while
adding native validity and SpiceDB-compatible Caveats.

SpiceDB is the behavioral reference for Caveats and qualifier identity. Its SQL
datastores keep Caveat name, relationship-bound Caveat context, and expiration
on the relationship row, while the resource/relation/subject columns remain the
relationship key. It does not permit two relationships that differ only by
Caveat or expiration. Relationship-bound context overrides request context for
the same key, and checks can return no permission, has permission, or
conditional permission with missing context fields.

Relevant inspected EACL areas include:

- `modules/eacl/src/eacl/relationships/storage.cljc`
- `modules/eacl/src/eacl/relationships/endpoint_pair.cljc`
- `modules/eacl/src/eacl/spicedb/parser.cljc`
- each backend schema, database adapter, writer, cleanup, and integrity module
- the cache, cursor, public authorization, and converged storage specifications

Relevant inspected SpiceDB areas include:

- `internal/datastore/common/sql.go`
- `internal/datastore/postgres/readwrite.go`
- `internal/datastore/postgres/schema/indexes.go`
- PostgreSQL, CockroachDB, and Spanner Caveat/expiration migrations
- the AuthZed Caveats and expiring-relationships contracts

## Goals / Non-Goals

### Goals

- Preserve exactly two authoritative endpoint datoms for every logical
  relationship.
- Preserve one authoritative endpoint attribute and one ordered seek per
  traversal direction.
- Freeze an eight-component v9 ABI that can support both native validity and
  Caveats without another relationship-storage break.
- Keep the first four components as the only logical relationship identity.
- Store arbitrary relationship-bound Caveat context outside the hot endpoint
  tuples, without reifying every relationship.
- Match SpiceDB Caveat context precedence, duplicate relationship, mutation,
  deletion, and conditional-result behavior.
- Make validity and Caveats sound under permission algebra, caches, cursors,
  speculative snapshots, cleanup, integrity, and unknown-writer proofs.
- Deliver validity first and Caveats second without changing tuple arity or
  component positions between phases.
- Reject populated old relationship stores rather than retain dual-read or
  migration complexity.

### Non-Goals

- Support multiple independently revocable grant assertions for the same
  subject/relation/resource identity.
- Support more than one Caveat attached to a single relationship.
- Support recurring schedules, time-zone recurrence rules, grant provenance,
  approvals, stable public grant IDs, or independent revocation tokens.
- Depend on Datahike's experimental transaction-level valid-time feature.
- Use a scheduler or garbage collector to make activation or expiration
  correct.
- Implement an automatic, online, offline, or mixed-format v7-to-v9
  relationship migration.
- Preserve arbitrary past valid-time reconstruction beyond each backend's
  configured history retention.
- Add further inline relationship qualifiers after v9; eight components consume
  Datomic's tuple arity budget.

## Decisions

### 1. Use one fixed eight-component v9 endpoint ABI

The authoritative values are:

```clojure
;; Forward value stored on subject-eid
[subject-type
 relation-eid
 resource-type
 resource-eid
 caveat-eid
 caveat-context-eid
 valid-from-ms
 valid-until-ms]

;; Reverse value stored on resource-eid
[resource-type
 relation-eid
 subject-type
 subject-eid
 caveat-eid
 caveat-context-eid
 valid-from-ms
 valid-until-ms]
```

Proposed persisted attribute names are:

```clojure
:eacl.v9.relationship/subject-type+relation+resource-type+resource+caveat+caveat-context+valid-from+valid-until
:eacl.v9.relationship/resource-type+relation+subject-type+subject+caveat+caveat-context+valid-from+valid-until
```

Datomic Pro, Datahike, and Datalevin declare:

```clojure
[:db.type/keyword
 :db.type/ref
 :db.type/keyword
 :db.type/ref
 :db.type/ref
 :db.type/ref
 :db.type/long
 :db.type/long]
```

DataScript stores the same fixed eight-element vector and enforces the same
logical types and cross-runtime integer range.

Every optional component remains physically present:

```text
slot 5 caveat-eid          nil when uncaveated
slot 6 caveat-context-eid  nil when no non-empty bound context exists
slot 7 valid-from-ms       nil when unbounded below
slot 8 valid-until-ms      nil when unbounded above
```

A context ref without a Caveat ref is invalid. A Caveat ref with a nil context
ref means the Caveat is attached with an empty relationship-bound context.

The first four components identify the relationship. Components five through
eight qualify that identity.

**Alternatives considered**

- **Bring back relationship entities.** Rejected. Efficient traversal would
  still require two covering indexes, while ordinary relationships would pay
  scalar-datom, lifecycle, write-amplification, and cache-density costs.
- **Use one Caveat-binding ref.** Rejected in favor of two explicit slots. A
  separate Caveat-definition ref plus optional context ref avoids an extra
  binding-definition datom, lets an empty-context Caveat allocate no
  relationship-specific entity, and mirrors SpiceDB's separate Caveat name and
  context columns.
- **Inline Caveat context.** Rejected. The arbitrary payload would be duplicated
  in both endpoint values and enlarge the hottest ordered indexes.
- **Use separate permanent and qualified relationship attributes.** Rejected.
  Negative checks and every enumeration or graph hop would need two seeks and
  an ordered merge.
- **Use a shorter Phase 1 tuple.** Rejected. It would force another persisted
  ABI migration when Phase 2 enables Caveats.

### 2. Put Caveat refs before validity, but keep all qualifiers trailing

The index-significant order remains:

```text
endpoint entity and attribute
  -> endpoint type
  -> relation eid
  -> opposite type
  -> opposite eid
  -> Caveat definition
  -> Caveat context
  -> valid-from
  -> valid-until
```

The decisive performance property is that all qualifiers follow the opposite
eid. Adjacency and pagination therefore remain ordered by the opposite eid, and
a normal graph hop uses one endpoint seek.

Among trailing qualifiers, Caveat-before-validity has no material effect on
ordinary lookup complexity because v9 permits only one stored relationship per
first-four identity. The chosen order instead provides these benefits:

- it mirrors SpiceDB's conceptual row order of Caveat, Caveat context, then
  expiration;
- it reserves Phase 2 positions before Phase 1 is released;
- it groups the two Caveat fields and the two validity fields;
- it lets the Caveat-free Phase 1 writer emit two explicit nils followed by the
  validity interval.

Physical component order does not dictate evaluation order. The engine reads
all eight components from one tuple value, rejects an inactive relationship
before dereferencing Caveat context, and invokes the Caveat evaluator only for
temporally active caveated edges.

A direct logical-identity probe seeks the first four components with full-arity
low/high sentinels. A relation scan seeks the first three components and pages
by component four. Every backend must use full eight-slot bounds where its
vector/tuple comparator requires equal arity.

**Alternative considered: leading validity.** Rejected. It would destroy
endpoint-local adjacency ranges, and one lexicographic ordering cannot make the
two-sided interval predicate `from <= t < until` a single complete range.

**Alternative considered: validity before Caveat.** Correct but not preferred.
It has the same hot-path complexity. The selected Caveat-first order better
matches the Phase 2 storage model and SpiceDB qualifier representation.

### 3. Store Caveat definitions as shared schema entities

Phase 2 adds schema-level Caveat entities with canonical identity, typed
parameters, source/AST payload, and compatibility profile. Conceptually:

```clojure
{:db/id caveat-eid
 :eacl/id "eacl.caveat:ip_allowlist"
 :eacl.caveat/name :ip_allowlist
 :eacl.caveat/parameters-payload canonical-parameters
 :eacl.caveat/expression-payload canonical-expression
 :eacl.caveat/profile :spicedb-v9}
```

The exact persisted payload fields may be consolidated, but the authoritative
representation must be deterministic, bounded, and included in schema
generation and schema-content proofs.

A relation type reference can allow a Caveat using SpiceDB-compatible syntax:

```zed
caveat ip_allowlist(user_ip ipaddress, cidr string) {
  user_ip.in_cidr(cidr)
}

definition device {
  relation viewer: user | user with ip_allowlist
}
```

The duplicate uncaveated and caveated subject branches make the Caveat
optional. A caveated branch without an uncaveated equivalent makes it required
for that subject form.

Each stored relationship has zero or one `caveat-eid`. The selected Caveat must
be allowed by the exact relation/subject-type/subject-relation branch.

### 4. Store non-empty relationship-bound context in a sparse context entity

Relationship-specific Caveat context lives in an internal entity referenced by
slot six:

```clojure
{:db/id context-eid
 :eacl.caveat-context/payload canonical-context}
```

The payload is one canonical, type-preserving, bounded value using EACL's secure
portable encoding. It represents a map of parameter names to partially bound
values. It is not stored as one attribute per context key.

The context entity:

- has no public object ID;
- exists only when the bound context is non-empty;
- is owned by exactly one logical relationship;
- is immutable after creation;
- is not deduplicated across relationships;
- is replaced atomically when `:touch` changes context;
- is retracted when the relationship is deleted or replaced;
- remains qualifier data rather than a graph vertex.

For a Caveat with no relationship-bound values:

```clojure
[..., caveat-eid nil valid-from valid-until]
```

No context entity is allocated. Request context can supply all required values.

For an uncaveated relationship:

```clojure
[..., nil nil valid-from valid-until]
```

No Caveat-specific entity or lookup exists.

This design costs one extra point read only when an active caveated relationship
has non-empty bound context. Caveat definitions are expected to come from the
compiled snapshot schema rather than an entity lookup per leaf.

**Alternative considered: always allocate a binding entity.** Rejected. It
would allocate at least one extra datom even for a Caveat with empty bound
context and add an unnecessary definition indirection.

**Alternative considered: shared context entities.** Rejected. Sharing would
require reference counting or global reachability collection and would make
safe deletion materially more complex.

### 5. Match SpiceDB relationship identity and mutation semantics

Exactly one stored relationship may exist for a logical identity:

```text
subject type/eid + relation eid + resource type/eid
```

Caveat definition, bound context, `valid-from`, and `valid-until` do not make
new identities. Two relationships differing only in these qualifiers cannot
coexist.

Public operation semantics are:

- `:create`: conflict when any stored v9 assertion has the same first four
  components, including future, expired, uncaveated, or differently caveated
  assertions;
- `:touch`: create when absent, otherwise atomically replace Caveat, context,
  validity, endpoint pair, and sparse auxiliary data;
- `:delete`: delete by logical identity without requiring Caveat, context, or
  validity values.

Commit-time conflict control must operate on the first four components, not
complete tuple equality. Out-of-band duplicate qualifier variants are
corruption. Authorization fails closed for that logical edge, while `:touch`
and `:delete` may remove all bounded variants and restore one canonical state.

This follows SpiceDB and avoids introducing implicit multiple-grant semantics.
If EACL later needs independently revocable grants, those are first-class grant
assertions with independent IDs, not duplicate v9 tuples.

### 6. Phase 1 implements fixed storage and native validity

Phase 1 installs and exclusively reads/writes the eight-slot v9 values. Caveat
slots five and six must be nil in admitted Phase 1 relationship writes. A
non-nil Caveat slot encountered from an out-of-band writer is non-granting and
reported as unsupported/corrupt until Phase 2 is enabled.

Validity uses the half-open interval:

```text
[valid-from, valid-until)
```

with activity at `t`:

```clojure
(and (or (nil? valid-from)  (<= valid-from t))
     (or (nil? valid-until) (< t valid-until)))
```

Bounds are normalized to exact UTC epoch-millisecond integers. Supplied bounds
must satisfy `valid-from < valid-until`.

Every top-level authorization view pairs one immutable database basis with one
trusted captured `valid-at-ms`. Client-targeted operations capture a fresh time
even when they reuse a minimize-latency database pin. Explicit EACL snapshots
freeze both basis and valid-time; `eacl/with` and `eacl/with-schema` preserve
that time.

Validity is checked before Caveat processing and before an edge participates in
union, intersection, exclusion, arrow traversal, recursion, lookup, or count.

### 7. Phase 2 implements SpiceDB-compatible Caveats

Phase 2 enables the already-reserved Caveat slots and adds:

- parsing and validation of top-level Caveat definitions and `with caveat`
  relation type references;
- canonical typed Caveat definitions and a versioned SpiceDB compatibility
  profile;
- relationship-write validation and sparse bound-context entities;
- request Caveat context on authorization and lookup operations;
- relationship-bound context precedence over request context for duplicate
  keys;
- deterministic bounded CEL evaluation;
- has-permission, no-permission, and conditional-permission results;
- missing-context field reporting;
- conditional-result composition through the complete permission algebra;
- complete cache, cursor, explanation, and proof dependencies.

The evaluator may have runtime-specific implementations, but all supported
runtimes must consume the same canonical typed representation and pass the same
SpiceDB-derived conformance corpus. Unsupported Caveat syntax, types, functions,
or values are rejected at schema/write admission rather than approximated.

The internal engine cannot collapse missing context to false too early. A leaf
may produce:

```clojure
{:permissionship :conditional-permission
 :residual-condition ...
 :missing-context #{...}}
```

Union, intersection, exclusion, and arrows combine residual conditions so an
unconditional granting witness can eliminate irrelevant conditions, while a
missing value that could still change the answer remains conditional.

The public Caveat-aware check returns a three-state result. Existing `can?`
remains a convenience Boolean and returns true only for
`:has-permission`; both `:no-permission` and `:conditional-permission` produce
false.

### 8. Bound context overrides request context

Phase 2 uses the SpiceDB merge rule:

```clojure
(effective-context request-context relationship-bound-context)
```

where values from the relationship-bound map replace request values with the
same key.

This prevents a caller from overriding policy values fixed when the relationship
was written. Context is validated against the Caveat parameter types before
evaluation. Unknown keys may be retained in request identity but are not visible
to an expression unless named by its parameter environment.

Both stored and request context are untrusted inputs and receive explicit limits
for depth, entry count, string/byte size, collection size, and encoded size
before compilation, evaluation, or cache-key construction.

### 9. Caveat and temporal data extend cache and cursor proofs

Relation-version equality remains necessary but is not sufficient.

Validity can change an answer without a database write. Reusable results
therefore carry a conservative temporal stability interval and are reusable only
when the selected `valid-at` remains inside it.

Caveat-influenced cache and cursor identity includes:

- the complete canonical request context relevant to the request;
- `caveat-eid` and the Caveat definition schema generation/content proof;
- `caveat-context-eid` and canonical payload/content proof;
- evaluator compatibility profile and implementation fingerprint;
- conditional/result kind, residual condition, and missing fields where stored;
- the ordinary complete relation dependency proof;
- the temporal stability interval.

Unknown-writer content proofs commit to both complete endpoint values and the
authoritative context payload. Mutating context in place is unsupported; managed
writers replace the immutable context entity and tuple reference. An out-of-band
mutation still changes the content proof.

Cursors authenticate request context and conditional semantics so context cannot
change between pages without a restart or typed mismatch.

### 10. Use a sparse expiration index, not time-leading endpoint tuples

A finite `valid-until` adds one EACL-owned sparse index value ordered by
expiration. It locates the exact endpoint pair for optional physical collection.
Permanent and start-only relationships add no expiration-index datom.

Authorization never consults the expiration index. Expired endpoint tuples are
non-granting immediately; collection only reclaims storage.

No mandatory global Caveat index is added. Caveat definition in-use validation
can enumerate the small set of relation definitions that allow that Caveat and
perform relation-prefix scans over their v9 forward values. A sparse
Caveat-usage index may be added later only if measured schema-write cost
justifies another caveated-relationship datom.

### 11. Keep authoritative history where the backend supports it

The endpoint pair, Caveat definition, and relationship-bound context are
authoritative. They retain normal history semantics where available. The
expiration index is derived and may use no-history/replaceable storage where a
backend supports it.

Transaction time and valid time remain distinct:

```text
database basis T + relationship valid-at V
```

Physical collection does not change present authorization but may limit
reconstruction from a current basis. Historical reconstruction remains subject
to backend retention.

### 12. Reject old relationship data; do not dual-read

v9 never reads the v7 endpoint attributes for authorization. Startup rejects:

- any v7 forward or reverse relationship datom;
- mixed v7/v9 relationship data;
- an incompatible relationship-storage version stamp.

Legacy Datomic attribute definitions may remain installed but inert. Operators
must rebuild or reseed relationship data into the v9 shape before running v9.
Old cache snapshots and cursors are rejected through ABI versioning.

This is intentionally not a migration design. Rebuild guidance and validation
are part of the release, but no conversion code or fallback path is shipped.

## Risks / Trade-offs

- **Eight slots consume Datomic's tuple arity ceiling** → Treat v9 as the final
  inline qualifier budget. Future provenance or independent grants use sparse
  side entities or a new assertion model, not a ninth slot.
- **Permanent relationships carry four nil qualifier values in each half** →
  Benchmark segment density and scan throughput against v7; retain one seek and
  two logical datoms as the primary performance target.
- **Bound Caveat context adds a point read for active caveated edges** → Keep
  context sparse, immutable, one-datom, and bypass the read when slot six is
  nil; cache decoded context under complete snapshot/content identity.
- **Caveat algebra and caching are security-sensitive** → Preserve residual
  conditions, include all context/evaluator dependencies, add adversarial
  cache tests, and compare a conformance corpus with SpiceDB.
- **Clock skew can change boundary behavior across peers** → Capture one trusted
  time per operation, require synchronized production clocks, document skew,
  and allow a fail-closed uncertainty margin where configured.
- **Out-of-band duplicate qualifier variants can exist because database set
  uniqueness applies to all eight slots** → Protect EACL attributes where
  possible, serialize admitted creates by first-four identity, detect duplicates
  on reads, and fail closed rather than selecting a winner.
- **No in-place upgrade path** → Fail startup before serving, provide explicit
  export/reseed instructions, and require backups before rebuild.
- **Different CEL runtimes can diverge** → Use one canonical typed IR, a
  versioned compatibility profile, shared test vectors, and runtime
  differential tests before Phase 2 release.

## Delivery Plan

### Phase 1 — v9 storage and native validity

1. Install the fixed eight-slot schema and bump storage/cache/cursor ABIs.
2. Reject populated v7 or mixed stores.
3. Replace endpoint codecs, scans, mutations, cleanup, integrity, and proofs.
4. Require Caveat slots five and six to be nil.
5. Add relationship validity, trusted valid-time snapshots, temporal filtering,
   and temporal stability proofs.
6. Add sparse expiration collection and rebuild/reseed documentation.
7. Benchmark all backends and release only after one-seek traversal and
   regression thresholds are demonstrated.

### Phase 2 — Caveats

1. Add Caveat grammar, canonical schema entities, relation type validation, and
   schema replacement safety.
2. Enable slot five and sparse slot-six context entities in writes and reads.
3. Add immutable context lifecycle and qualifier-aware touch/delete behavior.
4. Add typed CEL compilation/evaluation and SpiceDB-compatible context merge.
5. Add three-state public checks, missing-context reporting, and conditional
   lookup results.
6. Compose residual conditions through every permission operator.
7. Complete cache/cursor/proof/explanation scope and adversarial tests.
8. Run cross-runtime and SpiceDB differential conformance before declaring
   Caveat compatibility.

## Rebuild / Release Plan

1. Publish the v9 storage and API break before release.
2. Require operators to export logical Relationships and application data needed
   to recreate them.
3. Create a fresh database with the v9 physical schema.
4. Re-transact schema and Relationships through the v9 API.
5. Verify no v7 relationship datoms exist, forward/reverse parity holds, and
   the storage stamp is 9.
6. Run application authorization validation before switching traffic.
7. Do not start a v9 client against the old populated database.
8. Rollback uses the old database/backup and old EACL version; there is no
   in-place v9-to-v8 relationship downgrade.

## Open Questions

None. The tuple shape, component order, Caveat context location, relationship
identity, Phase 1/Phase 2 boundary, and rebuild-only compatibility policy are
decisions of this proposal.
